//This is a note from the team responsible for this project.
//It tells the professor about any extra work that was done or other things
//that need to be mentioned.
Optional use cases of adding a book and bookcopy 
and determining the overdue of given copy of book has been done.