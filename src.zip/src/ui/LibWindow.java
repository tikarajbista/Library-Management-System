package ui;

public interface LibWindow {
	void init();
	boolean isInitialized();
	void setInitialized(boolean val);
}
