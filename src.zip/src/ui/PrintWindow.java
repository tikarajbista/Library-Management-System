package ui;

import business.CheckOutRecordEntry;
import business.ControllerFactory;
import business.LibraryMember;
import business.ValidationException;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import ui.utils.WindowUtils;

public class PrintWindow extends Stage implements LibWindow{

	public static final PrintWindow INSTANCE = new PrintWindow();

	private boolean isInitialized = false;
	private TableView<CheckOutRecordEntry> tbv;
	private TextField txtMemberId;
	private TextField txtIsbn;
	private TextField txtBookCopyNum;
	private Label errorMessage;
	private LibraryMember member;

	private PrintWindow() {
	}

	@Override
	public void init() {
		try {

	        GridPane grid = new GridPane();
	        grid.setAlignment(Pos.CENTER_RIGHT);
	        grid.setHgap(20);
	        grid.setVgap(10);
	        grid.setPadding(new Insets(25, 25, 25, 25));

			ColumnConstraints col1 = new ColumnConstraints();
			col1.setPercentWidth(15);
			ColumnConstraints col2 = new ColumnConstraints();
			col2.setPercentWidth(35);
			ColumnConstraints col3 = new ColumnConstraints();
			col3.setPercentWidth(15);
			ColumnConstraints col4 = new ColumnConstraints();
			col4.setPercentWidth(35);
			grid.getColumnConstraints().addAll(col1,col2,col3,col4);
			grid.setPrefSize(700,500);

	        this.tbv = WindowUtils.createCheckOutRecordEntryListTableView();
			Label lbMemberId = new Label("Member ID:");
			txtMemberId = new TextField();
			
			Label lbIsbn = new Label("ISBN:");
			txtIsbn = new TextField();
			
			Label lbBookCopy = new Label("BookCopy Number:");
			txtBookCopyNum = new TextField();
			
			//grid.add(WindowUtils.createSceneText("Print check out record"), 0, 0, 4, 1);
			grid.add(lbMemberId, 0, 1);
			grid.add(txtMemberId, 1, 1);
			grid.add(lbIsbn,2,1);
			grid.add(txtIsbn, 3, 1);
			grid.add(lbBookCopy, 0, 2);
			grid.add(txtBookCopyNum, 1, 2);
			grid.add(this.tbv, 0, 3, 4, 4);

			HBox bBox = new HBox();
			grid.add(bBox, 2, 2, 2, 1);

			Button checkBtn = new Button("Checkout Record");
			checkBtn.setOnAction(e -> {
				this.errorMessage.setText("");

				member = ControllerFactory.of().getLibraryMember(this.txtMemberId.getText());
				if (member != null) {
					loadCheckOutRecordTableView(member);
					this.member = member;
				} else {
					reset();
					outputErrorMessage("Invalid ID!");
				}
			});

			Button returnBtn = new Button("Return Book");
			returnBtn.setOnAction(e -> {
				try {
					
					this.errorMessage.setText("Empty Copy!");
					ControllerFactory.of().returnRecord(this.txtMemberId.getText(), this.txtIsbn.getText(), this.txtBookCopyNum.getText());
					outputSuccessMessage("success");
				} catch (ValidationException e1) {
					// TODO Auto-generated catch block
					outputErrorMessage(e1.getMessage());
				}
				
				
			});
			
			Button renewBtn = new Button("Renew Book");
			renewBtn.setOnAction(e ->{
				ControllerFactory.of().renewRecord(this.txtMemberId.getText(), this.txtIsbn.getText(), this.txtBookCopyNum.getText());
			});
			
			bBox.setAlignment(Pos.BASELINE_RIGHT);
			bBox.getChildren().addAll(checkBtn, renewBtn);
			bBox.setSpacing(20);

			HBox pBox = new HBox();
			pBox.setAlignment(Pos.CENTER_RIGHT);
			pBox.getChildren().addAll( returnBtn , renewBtn);
			grid.add(pBox, 2, 7, 2, 1);


			Button backBtn = new Button("< Back");
			backBtn.setMinSize(150, 20);
			backBtn.setOnAction(e -> {
				Start.showOperationWindow();
			});
			grid.add(backBtn, 0, 7,2,1);

			errorMessage = new Label();
			grid.add(errorMessage,2,2);

	        //Scene scene = new Scene(grid, 300, 200);
	        Scene scene = new Scene(grid);
	        scene.getStylesheets().add(getClass().getResource("library.css").toExternalForm());
	        setScene(scene);

	        this.isInitialized = true;

		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	public void reset() {
		this.errorMessage.setText("");
		this.tbv.getItems().clear();
	}

	@Override
	public boolean isInitialized() {
		return isInitialized;
	}


	@Override
	public void setInitialized(boolean val) {
		isInitialized = val;
	}

	private void loadCheckOutRecordTableView(LibraryMember member) {
		this.tbv.getItems().clear();
		member.getCheckOutRecord().getEntryList().forEach( r -> this.tbv.getItems().add(r));
	}

	private void outputErrorMessage(String text) {
		errorMessage.setTextFill(Start.Colors.red);
		errorMessage.setText(text);
	}

	private void outputSuccessMessage(String text) {
		errorMessage.setTextFill(Start.Colors.green);
		errorMessage.setText(text);
	}

}
