package business;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import dataaccess.DataAccess;
import dataaccess.DataAccessFacade;
import dataaccess.User;


public class SystemController implements ControllerInterface {
	private User currentUser = null;
	private DataAccess da = new DataAccessFacade();
	private HashMap<String, User> usersMap;
	private HashMap<String, Book> booksMap;
	private HashMap<String, LibraryMember> membersMap;

	SystemController() {
		usersMap = da.readUserMap();
		booksMap = da.readBooksMap();
		membersMap = da.readMemberMap();
	};

	@Override
	public void login(String id, String password) throws LoginException {
		validateLogin(id, password);

		currentUser = usersMap.get(id);
	}
	
	void validateLogin(String id, String password) throws LoginException {
		if (!usersMap.containsKey(id)) {
			throw new LoginException("ID " + id + " not found");
		}

		String passwordFound = usersMap.get(id).getPassword();
		if (!passwordFound.equals(password)) {
			throw new LoginException("Password incorrect");
		}
	}

	@Override
	public List<String> allMemberIds() {
		DataAccess da = new DataAccessFacade();
		List<String> retval = new ArrayList<>();
		retval.addAll(da.readMemberMap().keySet());
		return retval;
	}

	@Override
	public List<String> allBookIds() {
		DataAccess da = new DataAccessFacade();
		List<String> retval = new ArrayList<>();
		retval.addAll(da.readBooksMap().keySet());
		return retval;
	}

	@Override
	public User getCurrentUser() {
		return currentUser;
	}

	@Override
	public HashMap<String, Book> getBooksMap() {
		return booksMap;
	}

	@Override
	public HashMap<String, Book> searchBooks(String isbn) {
		DataAccess da = new DataAccessFacade();
		HashMap<String, Book> retval = da.findBooksMap(isbn);
		return retval;
	}

	@Override
	public void validateCheckOutForm(String memberId, String isbn) throws ValidationException {
		if (!this.membersMap.containsKey(memberId)) {
			throw new ValidationException("Member is not exist!");
		}

		if (!this.booksMap.containsKey(isbn)) {
			throw new ValidationException("ISBN is not exist!");
		}

		if (this.booksMap.get(isbn).getNextAvailableCopy() == null) {
			throw new ValidationException(("No available copy for the book!"));
		}
	}

	@Override
	public LibraryMember getLibraryMember(String memberId) {
		return membersMap.get(memberId);
	}

	@Override
	public void checkOut(String memberId, String isbn) throws ValidationException {
		validateCheckOutForm(memberId, isbn);

		Book book = this.booksMap.get(isbn);
		BookCopy bookCopy = book.getNextAvailableCopy();
		bookCopy.changeAvailability();

		LibraryMember member = this.membersMap.get(memberId);
		member.getCheckOutRecord().addCheckOutRecord(LocalDate.now(),
				LocalDate.now().plusDays(book.getMaxCheckoutLength()), bookCopy);

		da.saveNewMember(this.membersMap.get(memberId));
		da.saveBook(book);
	}

	@Override
	public void updateBooksMap() {
		booksMap = da.readBooksMap();
	};

	@Override
	public void addACopy(Book book) {
		book.addCopy();
		da = new DataAccessFacade();
		da.saveNewCopy(book);
	}

	@Override
	public void addBook(String isbn, String title, String maxCheckoutLength, List<Author> authors, String copyNum)
			throws ValidationException {
		if (isbn == null || "".equals(isbn)) {
			throw new ValidationException("ISBN is empty");
		}

		if (title == null || "".equals(title)) {
			throw new ValidationException("Title is empty");
		}

		if (authors == null || authors.size() == 0) {
			throw new ValidationException("Authors is empty");
		}

		int l = 0;
		if (maxCheckoutLength == null || "".equals(maxCheckoutLength)) {
			throw new ValidationException("MaxCheckoutLength is invalid");
		} else {
			try {
				l = Integer.parseInt(maxCheckoutLength);
				if (l == 0) {
					throw new ValidationException("MaxCheckoutLength is invalid");
				}
			} catch (Exception e) {
				throw new ValidationException("MaxCheckoutLength is invalid");
			}
		}

		int n=0;
		if (copyNum == null || "".equals(copyNum)) {
			throw new ValidationException("Number of copies is invalid");
		} else {
			try {
				n = Integer.parseInt(copyNum);
				if (n == 0) {
					throw new ValidationException("Number of copies is invalid");
				}
			} catch (Exception e) {
				throw new ValidationException("Number of copies is invalid");
			}
		}


		if (booksMap.containsKey(isbn)) {
			throw new ValidationException("ISBN is already exist");
		}

		Book book = new Book(isbn, title, l, authors);
		while(book.getNumCopies() < n) {
			book.addCopy();
		}

		da.saveBook(book);
		booksMap.put(book.getIsbn(), book);
	}

	@Override
	public Author createAuthor(String f, String l, String t, String bio, String street, String city, String state,
			String zip) throws ValidationException {
		if (isEmpty(f)) {
			throw new ValidationException("FirstName is empty");
		}

		if (isEmpty(l)) {
			throw new ValidationException("LastName is empty");
		}

		Address address = null;
		if (!isEmpty(street) || !isEmpty(city) || !isEmpty(state) || !isEmpty(zip)) {
			address = new Address(street, city, state, zip);
		}
		return new Author(f, l, t, address, bio);
	}

	private boolean isEmpty(String t) {
		return (t == null || "".equals(t));
	}

	@Override
	public void returnRecord(String memberId, String isbn, String bookcopynum)throws ValidationException{
		validateReturnForm(memberId, isbn, bookcopynum);

		Book book = this.booksMap.get(isbn);
		BookCopy bookCopy = book.getCopy(Integer.parseInt(bookcopynum));
		LibraryMember member = this.membersMap.get(memberId);
		List<CheckOutRecordEntry> core = member.getCheckOutRecord().getEntryList();
		CheckOutRecordEntry ce = null;
		for(CheckOutRecordEntry c : core) {
			if(c.getBookCopy().getCopyNum() == (Integer.parseInt(bookcopynum))) {
				ce =c;
			}
		}
		core.remove(ce);
		bookCopy.changeAvailability();
		da.saveNewMember(this.membersMap.get(memberId));
		da.saveBook(book);
	}


   private void validateReturnForm(String memberId, String isbn, String bookcopynum) throws ValidationException {
	   
    	if (!this.membersMap.containsKey(memberId)  ) {
			throw new ValidationException("Member does not exist");
		}
    	if (memberId == null || memberId.equals(" ")) {
    		throw new ValidationException("Member ID is required!");
    	}
		if (!this.booksMap.containsKey(isbn)) {
			throw new ValidationException("ISBN is not exist!");
		}
		if (isbn == null || isbn.equals(" ")) {
    		throw new ValidationException("ISBN is required!");
    	}
		if(bookcopynum == null || bookcopynum.equals(" ")){
			throw new ValidationException("Book Copy is required");
		}
	}

	@Override
    public void validateAddMemberForm(String memberId, String firstName, String lastName,
    		String telephone, String street, String city, String state, String zip) throws ValidationException {

    	if (this.membersMap.containsKey(memberId)) {
            throw new ValidationException("Member ID already exists!");
        }

        if(memberId.isEmpty() ||
        		firstName.isEmpty() ||
        		lastName.isEmpty() ||
    			state.isEmpty() ||
    			city.isEmpty() ||
    			street.isEmpty() ||
    			telephone.isEmpty() ||
    			zip.isEmpty() ) {
        	throw new ValidationException("All fields are required!");
    	}

    }

    @Override
    public void addMember(String memberId, String firstName, String lastName,
    		String telephone, String street, String city, String state, String zip) {
    	Address address = new Address(street, city, state, zip);
    	LibraryMember member = new LibraryMember(memberId, firstName, lastName, telephone, address);
        da.saveNewMember(member);
        updateMembersMap();
    }

    @Override
    public void updateMembersMap() {
        membersMap = da.readMemberMap();
    };

    @Override
    public HashMap<String, LibraryMember> getMembersMap() {
        return membersMap;
    }

    @Override
    public HashMap<String, Overdue> getOverdues(String isbn) {
    	HashMap<String, Overdue> retval = da.findOverduesMap(booksMap.get(isbn));
		return retval;
    }


    @Override
    public void validateOverdueForm(String isbn) throws ValidationException {
    	 if (!this.booksMap.containsKey(isbn)) {
             throw new ValidationException("Book does not exist!");
         }
    }

	@Override
	public void renewRecord(String id, String isbn, String bc) {
		Book book = this.booksMap.get(isbn);
		LibraryMember member = this.membersMap.get(id);
		List<CheckOutRecordEntry> core = member.getCheckOutRecord().getEntryList();
		for(CheckOutRecordEntry c : core) {
			if(c.getBookCopy().getCopyNum() == (Integer.parseInt(bc))) {
				c.renewDate();
				break;
			}
		}
		da.saveNewMember(this.membersMap.get(id));
		//da.saveBook(book);
		
	}

}